--
-- PostgreSQL database dump
--

\restrict EdDXEnakYmBRV2XFBJUFHrUqvauAHDQIfBvNjR2xNlOkSQlLv1UrOkkcg854CbD

-- Dumped from database version 17.7 (Homebrew)
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adm_user; Type: TABLE; Schema: adm; Owner: gporcari
--

CREATE TABLE adm.adm_user (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __rec_md5 text,
    __ins_user text,
    username character varying(32),
    email text,
    mobile text,
    firstname text,
    lastname text,
    registration_date date,
    auth_tags text,
    status character varying(4),
    md5pwd character varying(65),
    locale character varying(12),
    language character varying(2),
    preferences text,
    menu_root_id character(22),
    avatar_rootpage text,
    sms_login boolean,
    sms_number text,
    photo text,
    group_code character varying(15),
    custom_menu text,
    custom_fields text,
    avatar_secret_2fa text,
    avatar_last_2fa_otp text,
    xgroup character varying(10)
);


ALTER TABLE adm.adm_user OWNER TO gporcari;

--
-- Data for Name: adm_user; Type: TABLE DATA; Schema: adm; Owner: gporcari
--

COPY adm.adm_user (id, __ins_ts, __del_ts, __mod_ts, __rec_md5, __ins_user, username, email, mobile, firstname, lastname, registration_date, auth_tags, status, md5pwd, locale, language, preferences, menu_root_id, avatar_rootpage, sms_login, sms_number, photo, group_code, custom_menu, custom_fields, avatar_secret_2fa, avatar_last_2fa_otp, xgroup) FROM stdin;
odEtzJzeMA_c9epKaAISIA	2026-02-20 10:00:00	\N	\N	\N	\N	james.wilson	james.wilson@testinvoice.com	\N	James	Wilson	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
mKPCLIt0NGuzecsY_KlxMw	2026-02-20 10:00:00	\N	\N	\N	\N	oliver.brown	oliver.brown@testinvoice.com	\N	Oliver	Brown	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
j_dl__etNOu5gJGBXqYXaQ	2026-02-20 10:00:00	\N	\N	\N	\N	sophia.davis	sophia.davis@testinvoice.com	\N	Sophia	Davis	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
GFUc9WODPUivhoaQnl__Dw	2026-02-20 10:00:00	\N	\N	\N	\N	liam.anderson	liam.anderson@testinvoice.com	\N	Liam	Anderson	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
o1sNd5A_OLW_nYbDpEBlIw	2026-02-20 10:00:00	\N	\N	\N	\N	charlotte.thomas	charlotte.thomas@testinvoice.com	\N	Charlotte	Thomas	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
X_QeQTfzM1mQW2_gTH3I1g	2026-02-20 10:00:00	\N	\N	\N	\N	noah.jackson	noah.jackson@testinvoice.com	\N	Noah	Jackson	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
oMIAHTf_OkGOyIUor9eDxg	2026-02-20 10:00:00	\N	\N	\N	\N	mia.white	mia.white@testinvoice.com	\N	Mia	White	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
hFY8fw1eOKecf02PidPHJQ	2026-02-20 10:00:00	\N	\N	\N	\N	william.harris	william.harris@testinvoice.com	\N	William	Harris	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
KTeJYx0aOO2Vt7cGPQUQVA	2026-02-20 10:00:00	\N	\N	\N	\N	lucas.thompson	lucas.thompson@testinvoice.com	\N	Lucas	Thompson	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1kYoBPXEMKah7kWZZVn_Rw	2026-02-20 10:00:00	\N	\N	\N	\N	isabella.garcia	isabella.garcia@testinvoice.com	\N	Isabella	Garcia	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
yT13YzLeMwOY_p5MLmTTzQ	2026-02-20 10:00:00	\N	\N	\N	\N	henry.martinez	henry.martinez@testinvoice.com	\N	Henry	Martinez	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6mTHlt3sMfywHavmeONGQw	2026-02-20 10:00:00	\N	\N	\N	\N	jack.clark	jack.clark@testinvoice.com	\N	Jack	Clark	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
G9zJ2nARMNix2ZhOPWw95Q	2026-02-20 10:00:00	\N	\N	\N	\N	ethan.walker	ethan.walker@testinvoice.com	\N	Ethan	Walker	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
SloqCEuqMAq1qtNitaGWgQ	2026-02-20 10:00:00	\N	\N	\N	\N	grace.hall	grace.hall@testinvoice.com	\N	Grace	Hall	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
0g_DhZsfOhGEjzTjxfPIEw	2026-02-20 10:00:00	\N	\N	\N	\N	mason.allen	mason.allen@testinvoice.com	\N	Mason	Allen	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8PNMgSlDMTqpmMal6XDmNA	2026-02-20 10:00:00	\N	\N	\N	\N	chloe.wright	chloe.wright@testinvoice.com	\N	Chloe	Wright	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
rlnPcsUVPjCVlqoiG9oZpg	2026-02-20 10:00:00	\N	\N	\N	\N	benjamin.lopez	benjamin.lopez@testinvoice.com	\N	Benjamin	Lopez	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
knjeBQgiOdKrs2gCtulyiA	2026-02-20 10:00:00	\N	\N	\N	\N	zoe.hill	zoe.hill@testinvoice.com	\N	Zoe	Hill	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
I_SczA80OqCDzeAyXVVORw	2026-02-20 10:00:00	\N	\N	\N	\N	sebastian.adams	sebastian.adams@testinvoice.com	\N	Sebastian	Adams	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
Is0icQhwPzKM_4QNuvmcNQ	2026-02-20 10:00:00	\N	\N	\N	\N	hannah.baker	hannah.baker@testinvoice.com	\N	Hannah	Baker	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
u5uv8PKaMNaO5wR5Ibp4uQ	2026-02-20 10:00:00	\N	\N	\N	\N	matthew.nelson	matthew.nelson@testinvoice.com	\N	Matthew	Nelson	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
eBu67U0VN66qPaGCyUwxuA	2026-02-20 10:00:00	\N	\N	\N	\N	samuel.mitchell	samuel.mitchell@testinvoice.com	\N	Samuel	Mitchell	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
AEWelySYOead9Z2ZX48bXg	2026-02-20 10:00:00	\N	\N	\N	\N	layla.perez	layla.perez@testinvoice.com	\N	Layla	Perez	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
FXN2GIQDP5SJhz_8q8QmmQ	2026-02-20 10:00:00	\N	2026-06-17 09:20:31.453783	\N	\N	ava.robinson	ava.robinson@testinvoice.com	\N	Ava	Robinson	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
dHXkItWEMsCQWXYmQ0uXBA	2026-02-20 10:00:00	\N	2026-06-17 09:21:04.782417	\N	\N	ella.lewis	ella.lewis@testinvoice.com	\N	Ella	Lewis	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
C7yo5O3MMXCC7kbBaqM42A	2026-02-20 10:00:00	\N	2026-06-17 09:21:26.683028	\N	\N	emma.taylor	emma.taylor@testinvoice.com	\N	Emma	Taylor	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
FfPNl8OYNemZ80GFkgezcA	2026-02-20 10:00:00	\N	2026-06-17 09:22:29.018704	\N	\N	aria.carter	aria.carter@testinvoice.com	\N	Aria	Carter	2026-01-01	level/green	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
U9YxUa38NHepunDNzJ3_Ow	2026-02-20 10:00:00	\N	2026-06-17 09:22:44.505491	\N	\N	daniel.scott	daniel.scott@testinvoice.com	\N	Daniel	Scott	2026-01-01	level/blue	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
X_MDROYPOKiMiG_iQpmMFg	2026-02-20 10:00:00	\N	2026-06-17 09:22:55.608955	\N	\N	lily.young	lily.young@testinvoice.com	\N	Lily	Young	2026-01-01	level/blue	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
f_w4l_ooN0uFzONshmRrXA	2026-02-20 10:00:00	\N	2026-06-17 09:23:19.229178	\N	\N	emily.green	emily.green@testinvoice.com	\N	Emily	Green	2026-01-01	level/canary	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
qednjONYMDujdXq7OdnDow	2026-02-20 10:00:00	\N	2026-06-17 11:11:28.066953	\N	\N	amelia.martin	amelia.martin@testinvoice.com	\N	Amelia	Martin	2026-01-01	_DEV_,_DOC_,_SYSTEM_,_TRD_,admin,superadmin,user,level/green	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	CANARY
Z54xiQLwM2iZw88QwJ1clQ	2026-02-20 10:00:00	\N	2026-06-21 07:22:36.75809	\N	\N	alexander.king	alexander.king@testinvoice.com	\N	Alexander	King	2026-01-01	user	conf	3be9ead13ed78a50e3ff6ccb0bc2c1d4:b47bcea5baada0999acd1fbaf6aad359	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Name: adm_user adm_user_pkey; Type: CONSTRAINT; Schema: adm; Owner: gporcari
--

ALTER TABLE ONLY adm.adm_user
    ADD CONSTRAINT adm_user_pkey PRIMARY KEY (id);


--
-- Name: adm_user cst_7d1bd291; Type: CONSTRAINT; Schema: adm; Owner: gporcari
--

ALTER TABLE ONLY adm.adm_user
    ADD CONSTRAINT cst_7d1bd291 UNIQUE (username);


--
-- Name: adm_user___del_ts_idx; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX adm_user___del_ts_idx ON adm.adm_user USING btree (__del_ts);


--
-- Name: adm_user___ins_ts_idx; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX adm_user___ins_ts_idx ON adm.adm_user USING btree (__ins_ts);


--
-- Name: adm_user___mod_ts_idx; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX adm_user___mod_ts_idx ON adm.adm_user USING btree (__mod_ts);


--
-- Name: adm_user_group_code_idx; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX adm_user_group_code_idx ON adm.adm_user USING btree (group_code);


--
-- Name: adm_user_language_idx; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX adm_user_language_idx ON adm.adm_user USING btree (language);


--
-- Name: adm_user_username_idx; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE UNIQUE INDEX adm_user_username_idx ON adm.adm_user USING btree (username);


--
-- Name: idx_449003ec; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX idx_449003ec ON adm.adm_user USING btree (__mod_ts);


--
-- Name: idx_4ba3c505; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX idx_4ba3c505 ON adm.adm_user USING btree (language);


--
-- Name: idx_5fd0c3cf; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX idx_5fd0c3cf ON adm.adm_user USING btree (xgroup);


--
-- Name: idx_ac84de89; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX idx_ac84de89 ON adm.adm_user USING btree (__ins_ts);


--
-- Name: idx_d5b2fef2; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX idx_d5b2fef2 ON adm.adm_user USING btree (__del_ts);


--
-- Name: idx_e6d34426; Type: INDEX; Schema: adm; Owner: gporcari
--

CREATE INDEX idx_e6d34426 ON adm.adm_user USING btree (group_code);


--
-- Name: adm_user fk_8b2a513d; Type: FK CONSTRAINT; Schema: adm; Owner: gporcari
--

ALTER TABLE ONLY adm.adm_user
    ADD CONSTRAINT fk_8b2a513d FOREIGN KEY (xgroup) REFERENCES adm.adm_xgroup(code) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adm_user fk_e66015dd; Type: FK CONSTRAINT; Schema: adm; Owner: gporcari
--

ALTER TABLE ONLY adm.adm_user
    ADD CONSTRAINT fk_e66015dd FOREIGN KEY (group_code) REFERENCES adm.adm_group(code) ON UPDATE CASCADE;


--
-- Name: TABLE adm_user; Type: ACL; Schema: adm; Owner: gporcari
--

GRANT SELECT ON TABLE adm.adm_user TO gnrai_reader;


--
-- PostgreSQL database dump complete
--

\unrestrict EdDXEnakYmBRV2XFBJUFHrUqvauAHDQIfBvNjR2xNlOkSQlLv1UrOkkcg854CbD

